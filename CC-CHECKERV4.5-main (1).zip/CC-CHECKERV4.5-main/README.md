# CC-CHECKERV4.5

![PHP](https://img.shields.io/badge/language-PHP-blue.svg)
![DARKXCODE](https://img.shields.io/badge/Team-DARKXCODE-black)
![AUTHOR](https://img.shields.io/badge/Author-Zlaxtert-orange)

Tools CC bulk checker Version 4.5 [CLI Version][UPDATE 14 July 2025]. Payment gateways Stripe, Braintree, Vbv check.


## Install on desktop : 
- Install XAMPP
- Added environment variable system path => C:\xampp\php
- download the script and save it in your folder
- open CMD and running

## Install on android (Termux)
    $ pkg install git -y
    $ pkg install php -y
    $ git clone https://github.com/zlaxtertdev/CC-CHECKERV4.5.git
    $ cd CC-CHECKERV4.5
    $ php cli.php

## Screenshot Tools
<img src="https://github.com/zlaxtertdev/CC-CHECKERV4.5/blob/main/ress.png">




